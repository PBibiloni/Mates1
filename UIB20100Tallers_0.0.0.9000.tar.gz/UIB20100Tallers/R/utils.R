

tallers.utils.output = function(list_outputs, header=" ") {
  list_outputs = Filter(Negate(is.null), list_outputs)
  list_outputs = lapply(list_outputs, tallers.utils.encodehtml)
  df = data.frame(v=matrix(unlist(list_outputs), nrow=length(list_outputs), byrow=T),
                  stringsAsFactors = FALSE)
  rownames(df) = lapply(names(list_outputs), tallers.utils.encodehtml)
  return(knitr::kable(df, col.names = c(header)))
}

tallers.utils.outputcodi = function(vector_lines, header="Codi") {
  vector_lines = lapply(vector_lines, tallers.utils.encodehtml)
  df = data.frame(Codi=paste("`", vector_lines, "`", sep=""),
                  stringsAsFactors = FALSE)
  return(knitr::kable(df, col.names = c(header)))
}

tallers.utils.encodehtml = function(string) {
  specialchars = list(
    "á"="&aacute;", "à"="&agrave;", "Á"="&Aacute;", "À"="&Agrave;", "ä"="&auml;", "Ä"="&Auml;",
    "é"="&eacute;", "è"="&egrave;", "É"="&Eacute;", "È"="&Egrave;", "ë"="&euml;", "Ë"="&Euml;",
    "í"="&iacute;", "ì"="&igrave;", "Í"="&Iacute;", "Ì"="&Igrave;", "ï"="&iuml;", "Ï"="&Iuml;",
    "ó"="&oacute;", "ò"="&ograve;", "Ó"="&Oacute;", "Ò"="&Ograve;", "ö"="&ouml;", "Ö"="&Ouml;",
    "ú"="&uacute;", "ù"="&ugrave;", "Ú"="&Uacute;", "Ù"="&Ugrave;", "ü"="&uuml;", "Ü"="&Uuml;",
    "ç"="&Ccedil;", "Ç"="&ccedil;",
    "ñ"="&ntilde;", "Ñ"="&Ntilde;",
    "º"="&deg;",
    "\n"="" # Also, avoid line breaks within a string
  )
  result <- string
  for (pattern in names(specialchars)) {
    result <- gsub(pattern, specialchars[[pattern]], result)
  }
  return(result)
}

tallers.utils.checknumber = function(
    expected_value, given_value, max_relative_error=3e-2) {
  stopifnot("El valor esperat hauria de ser un unic nombre!"=length(expected_value)==1 & is.numeric(expected_value))
  stopifnot("El valor donat hauria de ser un unic nombre!"=length(given_value)==1 & is.numeric(given_value))
  return(abs(expected_value - given_value) <= abs(max_relative_error*expected_value))
}
