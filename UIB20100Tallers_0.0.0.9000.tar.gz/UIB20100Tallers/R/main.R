
#' @export
tallers.configura = function(taller=NULL, alumne=NULL, clau=NULL) {
  stopifnot("El parametre `taller` ha de ser un unic nombre enter"=is.numeric(taller) & length(taller)==1)
  stopifnot("El parametre `alumne` ha de ser una cadena de text"=is.character(alumne) & length(alumne)==1)
  stopifnot("El parametre `alumne` ha de ser el teu nom complet"=nchar(alumne)>=11)
  stopifnot("El parametre `clau` ha de ser un unic nombre enter"=is.numeric(clau) & length(clau)==1)

  t1()
  info = tallers.getinfo(num_taller=taller)
  stopifnot("Completa el nom"=alumne!="Nom, Cognoms")
  stopifnot("El nombre de taller no es correcte"=!is.null(info))
  stopifnot("La clau no es correcta"=info[["clau"]] == clau)

  assign("tallers.data.num_taller", taller, envir = cacheEnv)
  assign("tallers.data.alumne", alumne, envir = cacheEnv)

  alumne_chars = utf8ToInt(iconv(alumne, "UTF-8", "UTF-8",sub=''))
  alumne_seed = cumsum(alumne_chars * seq(3, 1+2*length(alumne_chars), by=2))
  seed = taller + 2 * clau + alumne_seed
  assign("tallers.data.seed", seed, envir = cacheEnv)

  output = list(
    alumne = alumne,
    clau = clau
  )
  for (num_p in seq(1, info[["num_preguntes"]])) {
    p = tallers.getpregunta(num_taller=taller, num_pregunt=num_p)
    k = sprintf("Pregunta %2d", num_p)
    output[[k]] = sprintf("[%d punts]", p[["punts"]])
  }
  rubrica = info[["rubrica"]]
  rubrica_extra_punts = info[["rubrica_extra_punts"]]
  if (length(rubrica) > 0) {
    if (rubrica_extra_punts == 0) {
      output[["Rúbrica"]] = rubrica
    } else {
      output[["Rúbrica"]] = sprintf("[%d punts] %s", rubrica_extra_punts, rubrica)
    }
  }

  tallers.utils.output(output, header=sprintf("Resum Taller %d", taller))
}

#' @export
tallers.enunciat = function(num_pregunta) {
  pregunta = tallers.getpregunta(
    num_taller=get("tallers.data.num_taller", envir=cacheEnv),
    num_pregunta=num_pregunta)
  preg_header = sprintf("Pregunta %2d - Enunciat", num_pregunta)


  if(is.null(pregunta$fun_inicialitzacio_aleatoria)) {
    preg_dades = NULL
  } else {
    set.seed(get("tallers.data.seed", envir=cacheEnv))
    preg_dades = pregunta$fun_inicialitzacio_aleatoria()
  }

  caller = parent.frame()
  if(is.null(pregunta$fun_variables_per_alumne)) {
    preg_info = NULL
  } else {
    preg_varlists = pregunta$fun_variables_per_alumne(preg_dades)
    preg_varnames = names(preg_varlists)
    for(n in preg_varnames) {
      v = preg_varlists[[n]]
      caller[[n]] = v
    }
    preg_info = paste(preg_varnames, sep="`, `", collapse="`, `")
    preg_info = paste("Tens disponibles les variables: `", preg_info, "`.", sep="")
  }

  if(is.null(pregunta$fun_comprova)) {
    preg_punts = sprintf("%2d (Correcció manual)", pregunta$punts)
  } else {
    preg_punts = sprintf("%2d", pregunta$punts)
  }

  preg_str = pregunta$fun_pregunta_com_str(dades=preg_dades)
  k1 = tallers.utils.output(list(
    " " = preg_str,
    "Dades:" = preg_info,
    "Punts:" = preg_punts
  ), header=preg_header)

  if(is.null(pregunta$fun_codi_per_alumne)) {
    knitr::kables(list(k1))
  } else {
    preg_codi_body = capture.output(print(pregunta$fun_codi_per_alumne))
    preg_codi_body = preg_codi_body[3:length(preg_codi_body)-1]
    if(preg_codi_body[1] == '{') {
      preg_codi_body = preg_codi_body[-1]
    }
    k2 = tallers.utils.outputcodi(
      preg_codi_body,
      header="Codi d'exemple")
    knitr::kables(list(k1, k2))
  }
}

#' @export
tallers.comprova = function(num_pregunta, ...) {
  pregunta = tallers.getpregunta(
    num_taller=get("tallers.data.num_taller", envir=cacheEnv),
    num_pregunta=num_pregunta)
  preg_header = sprintf("Pregunta %2d - Resposta", num_pregunta)

  if(is.null(pregunta$fun_inicialitzacio_aleatoria)) {
    preg_dades = NULL
  } else {
    set.seed(get("tallers.data.seed", envir=cacheEnv))
    preg_dades = pregunta$fun_inicialitzacio_aleatoria()
  }

  if(is.null(pregunta$fun_comprova)) {
    resp_str = "Pregunta amb correcció manual."
    resp_punts = sprintf("??/%2d", pregunta$punts)
  } else {
    preg_check = pregunta$fun_comprova(dades=preg_dades, ...)
    if(preg_check) {
      resp_str = "Resposta correcta!"
      resp_punts = sprintf("%2d/%2d", pregunta$punts, pregunta$punts)
      knitr::kable(data.frame(Resposta = "Resposta correcta!"))
    } else {
      resp_str = "Resposta incorrecta!"
      resp_punts = sprintf(" 0/%2d", pregunta$punts)
      knitr::kable(data.frame(Pregunta = "Resposta incorrecta!"))
    }
  }

  preg_str = pregunta$fun_pregunta_com_str(dades=preg_dades)
  tallers.utils.output(list(
    " " = preg_str,
    # "Resposta donada:" = capture.output(print(list(...))),
    "Correcci&oacute;:" = resp_str,
    "Punts:" = resp_punts
  ), header=preg_header)
}

tallers.getpregunta = function(num_taller, num_pregunta) {
  set.seed(get("tallers.data.seed", envir=cacheEnv) + num_taller + num_pregunta)
  categoria = sprintf("%04d-%04d", num_taller, num_pregunta)

  tallers.preguntes = get("tallers.preguntes", envir=cacheEnv)
  preguntes_cat = tallers.preguntes[[categoria]]
  pregunta = sample(preguntes_cat, 1)[[1]]
  return(pregunta)
}

tallers.afegeixpregunta = function(
  # Identificació de la pregunta.
  # Si afegim més d'una pregunta per un num_taller/num_preg, es seleccionarà una a l'atzar
  num_taller,     # Integer
  num_pregunta,   # Integer
  punts,    # Totes les del mateix num_taller/num_pregunta haurien de tenir el mateix valor en punts
  # Contingut de la pregunta.
  # Funcions que permeten aleatoritzar les dades i comprovar la resposta.
  fun_inicialitzacio_aleatoria, # dades <- function(). Obviar si no cal.
  fun_pregunta_com_str,         # enunciat_str <- function(dades)
  fun_variables_per_alumne,     # list_variables_to_give <- function(dades). Obviar si no cal.
  fun_codi_per_alumne,          # function(), no s'executarà (només es mostrarà el codi). Obviar si no cal.
  fun_comprova                  # boolean_truefalse <- function(dades, resposta). Obviar si la correcció és manual.
) {
  tallers.preguntes = get("tallers.preguntes", envir=cacheEnv)

  tallers.configura_info(num_taller=num_taller, num_pregunta=num_pregunta)
  if(missing(fun_inicialitzacio_aleatoria)){
    fun_inicialitzacio_aleatoria = NULL
  }
  if(missing(fun_variables_per_alumne)){
    fun_variables_per_alumne = NULL
  }
  if(missing(fun_codi_per_alumne)){
    fun_codi_per_alumne = NULL
  }
  if(missing(fun_comprova)){
    fun_comprova = NULL
  }
  categoria = sprintf("%04d-%04d", num_taller, num_pregunta)
  preguntes_cat = tallers.preguntes[[categoria]]
  if(is.null(preguntes_cat)) {
    preguntes_cat = list()
  }
  num_versio = length(preguntes_cat)+1
  preguntes_cat[[sprintf("versio_%d", num_versio)]] = list(
      num_taller = num_taller,
      num_pregunta = num_pregunta,
      num_versio = num_versio,
      punts = punts,
      fun_inicialitzacio_aleatoria = fun_inicialitzacio_aleatoria,
      fun_pregunta_com_str = fun_pregunta_com_str,
      fun_variables_per_alumne = fun_variables_per_alumne,
      fun_codi_per_alumne = fun_codi_per_alumne,
      fun_comprova = fun_comprova)

  tallers.preguntes[[categoria]] = preguntes_cat
  assign("tallers.preguntes", tallers.preguntes, envir = cacheEnv)
}

tallers.configura_info = function(
  num_taller,
  clau=NULL,
  rubrica=NULL,
  rubrica_extra_punts=NULL,
  num_pregunta=NULL
) {
  tallers.infotaller = get("tallers.infotaller", envir=cacheEnv)
  info = tallers.infotaller[[sprintf("%d", num_taller)]]
  if( is.null(info) ) {
    info = list(
      num_taller = num_taller,
      clau=0,
      rubrica = NULL,
      rubrica_extra_punts = 0,
      num_preguntes = 0
    )
  }

  if ( length(clau) > 0 ) {
    stopifnot("La clau ja s'ha inicialitzat"=clau!=0)
    info[["clau"]] = clau
  }

  if ( length(rubrica) > 0 ) {
    stopifnot("El parametre `rubrica` ha de ser una cadena de text"=is.character(rubrica) & length(rubrica)==1)
    info[["rubrica"]] = rubrica

    if ( length(rubrica_extra_punts) > 0 ) {
      stopifnot("El parametre `rubrica_extra_punts` ha de ser un unic nombre enter"=is.numeric(rubrica_extra_punts) & length(rubrica_extra_punts)==1)
      info[["rubrica_extra_punts"]] = rubrica_extra_punts
    }
  } else if ( length(rubrica_extra_punts) > 0 ) {
    stop("No podem assignar `rubrica_extra_punts` sense `rubrica`")
  }

  if ( length(num_pregunta) > 0 ) {
    stopifnot("El parametre `num_pregunta` ha de ser un unic nombre enter"=is.numeric(num_pregunta) & length(num_pregunta)==1)
    if (num_pregunta == info[["num_preguntes"]] + 1) {
      info[["num_preguntes"]] = num_pregunta
    } else if (num_pregunta > info[["num_preguntes"]] + 1) {
      # stop(sprintf("Intentam registrar la pregunta %02d, pero al taller %d
      #               nomes existeix fins la pregunta %02d",
      #              num_pregunta, num_taller, info[["num_preguntes"]]))
    }
  }

  tallers.infotaller[[sprintf("%d", num_taller)]] = info
  assign("tallers.infotaller", tallers.infotaller, envir = cacheEnv)
}

tallers.getinfo = function(num_taller) {
  tallers.infotaller = get("tallers.infotaller", envir=cacheEnv)
  return(tallers.infotaller[[sprintf("%d", num_taller)]])
}

cacheEnv <- new.env()
assign("tallers.infotaller", list(), envir = cacheEnv)
assign("tallers.preguntes", list(), envir = cacheEnv)
tallers.infotaller = list()
tallers.preguntes = list()







t1 = function() {

  # source("R/utils.R")

  tallers.configura_info(
    num_taller=1,
    rubrica="Entrega el fitxer .Rmd i l'informe .html generat. A l'informe, explica
           el codi que utilitzis i el resultat que has obtingut.",
    rubrica_extra_punts=2,
    clau=21431
  )

  tallers.afegeixpregunta(
    num_taller=1,
    num_pregunta=1,
    punts=2,
    fun_inicialitzacio_aleatoria = function() {
      dades = data.frame(
        n = sample(seq(20, 90, by=10), 1)
      )
      return(dades)
    },
    fun_pregunta_com_str = function(dades) {
      return(sprintf("Calcula el logaritme de n=%d en base b=10", dades$n))
    },
    fun_comprova = function(dades, resposta) {
      return(tallers.utils.checknumber(resposta, log(dades$n, base=10)))
    }
  )


  tallers.afegeixpregunta(
    num_taller=1,
    num_pregunta=2,
    punts=2,
    fun_inicialitzacio_aleatoria = function() {
      dades = data.frame(
        a = sample(3:8, 1),
        b = sample(3:8, 1),
        c = sample(3:8, 1)
      )
      return(dades)
    },
    fun_pregunta_com_str = function(dades) {
      return(sprintf("Resol les següents equacions:
                    $%d = %d \\cdot x^{%d}$,
                    $%d = %d \\cdot {%d}^{y}$",
                     dades$a, dades$b, dades$c,
                     dades$a, dades$b, dades$c))
    },
    fun_comprova = function(dades, x=1, y=0) {
      return(
        tallers.utils.checknumber(dades$a, dades$b * x**(dades$c)) &
          tallers.utils.checknumber(dades$a, dades$b * dades$c**y)
      )
    }
  )


  tallers.afegeixpregunta(
    num_taller=1,
    num_pregunta=3,
    punts=2,
    fun_inicialitzacio_aleatoria = function() {
      dades = data.frame(
        temps = 1:10,
        temperatura = 50 + sample(3:7, 1)*(1:10) + sample(3:7, 1)*runif(10)
      )
      return(dades)
    },
    fun_pregunta_com_str = function(dades) {
      return("En un experiment hem mesurat la temperatura [ºC] d'un sòlid en
           diferents instants de temps [s]. Hem guardat les dades a la variable
           `dades_experimentals`. Representa amb un gràfic lineal la temperatura
           en funció del temps, i dibuixa la recta de regressió lineal.")
    },
    fun_variables_per_alumne = function(dades) {
      vars = list(dades_experimentals=dades)
      return(vars)
    },
    fun_codi_per_alumne = function() {
      # Pots inspeccionar les dades:
      summary(dades_experimentals)
      # Per representar gràfiques adapta l'instrucció:
      plot(x = ..., y = ..., xlab = "Etiqueta eix X", ylab = "Etiqueta eix Y")
      # I per calcular/mostrar el model lineal:
      model = lm(VariableDepenent ~ VariableIndependent, data = dades_experimentals)
      abline(model)
    }
  )


  tallers.afegeixpregunta(
    num_taller=1,
    num_pregunta=4,
    punts=2,
    fun_inicialitzacio_aleatoria = function() {
      dades = data.frame(
        temps = 1:10,
        temperatura = 50 + sample(3:7, 1)*(1:10) + sample(3:7, 1)*runif(10)
      )
      return(dades)
    },
    fun_pregunta_com_str = function(dades) {
      return("Amb les dades de l'experiment de la pregunta anterior, no sabem si un
           ajust lineal és millor o pitjor que un ajust exponencial. Troba els
           paràmetres $a, b$ del millor ajust exponencial, que serà de la forma
           $y(x) = a \\cdot e^{b \\cdot x}$.")
    },
    fun_variables_per_alumne = function(dades) {
      vars = list(dades_experimentals=dades)
      return(vars)
    },
    fun_codi_per_alumne = function() {
      # Pots inspeccionar les dades:
      summary(dades_experimentals)
      # Per representar gràfiques adapta l'instrucció:
      plot(x = ..., y = ..., xlab = "Etiqueta eix X", ylab = "Etiqueta eix Y")
      # I per calcular/mostrar el model lineal:
      model = lm(VariableDepenent ~ VariableIndependent, data = dades_experimentals)
      abline(model)
    },
    fun_comprova = function(dades, a, b) {
      model = lm(log(temperatura) ~ temps, data = dades_experimentals)
      return(
        tallers.utils.checknumber(a, exp(model$coefficients[[1]])) &
          tallers.utils.checknumber(b, exp(model$coefficients[[1]]))
      )
    }
  )







}
