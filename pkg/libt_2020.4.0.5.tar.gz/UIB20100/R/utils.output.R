

lib.uib20100.utils.output = function(list_outputs, list_extra_kables=list(), header=" ", decimals=2) {
  if(is.null(names(list_outputs))) {
    names(list_outputs) = lapply(seq_along(list_outputs), function(i) {paste(rep(' ', i), collapse=" ")})
  }

  list_outputs = Filter(Negate(is.null), list_outputs)
  if(knitr::is_html_output() | knitr::is_latex_output()) {
    format = "html"
    for(n in names(list_outputs)) {
      outp = list_outputs[[n]]
      if(is.matrix(outp)) {
        list_outputs[[n]] = lib.uib20100.utils.matrix2latex(outp, decimals = decimals)
      }
    }
  } else {
    list_matrices = Filter(is.matrix, list_outputs)
    list_outputs = Filter(Negate(is.matrix), list_outputs)
    list_extra_kables = append(
      list_extra_kables,
      lapply(names(list_matrices), function(n) {
        lib.uib20100.utils.matrix2strkable(list_matrices[[n]], label=n, decimals = decimals)
      })
    )
    if(length(list_matrices) == 0) {
      format = 'html'
    } else {
      format = 'simple'
    }
  }

  for(n in names(list_outputs)) {
    outp = list_outputs[[n]]
    if(is.numeric(outp)) {
      list_outputs[[n]] = lib.uib20100.utils.number2str(outp, max_decimals = decimals)
    }
  }
  df = data.frame(v=matrix(unlist(list_outputs), nrow=length(list_outputs), byrow=T),
                  stringsAsFactors = FALSE)
  rownames(df) = lapply(names(list_outputs), lib.uib20100.utils.encodehtml)
  k_outputs = knitr::kable(df, col.names = c(header), format=format, escape=FALSE)
  if(length(list_extra_kables) == 0) {
    return(k_outputs)
  } else {
    return(knitr::kables(append(k_outputs, list_extra_kables)))
  }
}

lib.uib20100.utils.outputcodi = function(multiline_string, header="Codi") {
  list_lines = strsplit(multiline_string, "\n")[[1]]
  list_lines = lapply(list_lines, function(l) {
    trimws(l, which = c("both", "left", "right"))})
  list_lines = Filter(function(l) {nchar(l) > 0}, list_lines)
  # list_lines = lapply(list_lines, lib.uib20100.utils.encodehtml)
  df = data.frame(Codi=paste("`", unlist(list_lines, use.names=FALSE), "`", sep=""),
                  stringsAsFactors = FALSE)
  return(knitr::kable(df, col.names = c(header)))
}

lib.uib20100.utils.outputerror = function(error_str) {
  return(lib.uib20100.utils.output(
    list(" " = error_str),
    header="ERROR"))
}

lib.uib20100.utils.outputerror.noconfig = function() {
  return(lib.uib20100.utils.outputerror(
    "Encara no has configurat el taller. Executa el chunk que
      conté la instrucció `configura.taller( ... )` i comprova que no dona cap error."
  ))
}



lib.uib20100.utils.encodehtml = function(string) {
  specialchars = list(
    "á"="&aacute;", "à"="&agrave;", "Á"="&Aacute;", "À"="&Agrave;", "ä"="&auml;", "Ä"="&Auml;",
    "é"="&eacute;", "è"="&egrave;", "É"="&Eacute;", "È"="&Egrave;", "ë"="&euml;", "Ë"="&Euml;",
    "í"="&iacute;", "ì"="&igrave;", "Í"="&Iacute;", "Ì"="&Igrave;", "ï"="&iuml;", "Ï"="&Iuml;",
    "ó"="&oacute;", "ò"="&ograve;", "Ó"="&Oacute;", "Ò"="&Ograve;", "ö"="&ouml;", "Ö"="&Ouml;",
    "ú"="&uacute;", "ù"="&ugrave;", "Ú"="&Uacute;", "Ù"="&Ugrave;", "ü"="&uuml;", "Ü"="&Uuml;",
    "ç"="&ccedil;", "Ç"="&ccedil;",
    "ñ"="&ntilde;", "Ñ"="&Ntilde;",
    "º"="&deg;",
    "\n"="" # Also, avoid line breaks within a string
  )
  result <- string
  for (pattern in names(specialchars)) {
    result <- gsub(pattern, specialchars[[pattern]], result)
  }
  return(result)
}




lib.uib20100.utils.number2str <- function(x, max_decimals=2) {
  x = round(x, digits=max_decimals)
  x = sapply(x, function(x) {
    if(Im(x) == 1 & Re(x) == 0) {
      return("i")
    }
    if(Im(x) == -1 & Re(x) == 0) {
      return("-i")
    }
    if(Im(x) != 0 & Re(x) == 0) {
      return(paste(Im(x), "i", sep=""))
    }
    if(Im(x) == 0) {
      return(paste(Re(x)))
    }
    return(paste(x))
  })
}

lib.uib20100.utils.matrix2latex <- function(A, decimals=2, environment="pmatrix") {
  if(is.null(dim(A))) {   # Un escalar
    return(lib.uib20100.utils.number2str(A, max_decimals=decimals))
  }
  A = t(A)
  A = apply(A, 1, lib.uib20100.utils.number2str, max_decimals=decimals)
  A[A == "NA"] = "-"
  paste(
    "\\begin{", environment, "}\n \t ",
    paste(apply(A, 1, function(x) {paste(x , collapse=" & ")}), collapse=" \\\\ \n \t "),
    "\n\\end{", environment, "}",
    sep = "")
}

lib.uib20100.utils.matrix2strkable = function(A, label="", decimals=2) {
  if(is.null(dim(A))) {
    return(sprintf("%s%s", label, lib.uib20100.utils.number2str(A, max_decimals=decimals)))
  }
  A = t(A)
  A = apply(A, 1, lib.uib20100.utils.number2str, max_decimals=decimals)
  etiqueta = matrix(rep("", times=dim(A)[[1]]), ncol=1)
  etiqueta[round(dim(A)[[1]]/2), 1] = label
  if(dim(A)[[1]] == 1 & dim(A)[[2]] == 1) {
    padding_left = matrix(" ", ncol=1)
    padding_right = matrix(" ", ncol=1)
  } else if(dim(A)[[1]] == 1) {
    padding_left = matrix("(", ncol=1)
    padding_right = matrix(")", ncol=1)
  } else {
    padding_left = matrix(c('/', rep("|", times=dim(A)[[1]]-2), '\\'), ncol=1)
    padding_right = matrix(c('\\', rep("|", times=dim(A)[[1]]-2), '/'), ncol=1)
  }
  A_str = cbind(etiqueta, padding_left, A, padding_right)

  return(knitr::kable(
    A_str,
    col.names=rep(" ", times=dim(A_str)[[2]]),
    align = paste(c('c', rep('r', dim(A)[[1]]), 'c'), sep=""),
    format = 'simple'
  ))
}
