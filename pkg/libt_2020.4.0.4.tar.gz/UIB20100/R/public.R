
###
# TALLERS
###


#' @export
tallers.configura = function(taller=NULL, alumne=NULL, clau=NULL) {
  lib.uib20100.configura(taller=taller, alumne=alumne, clau=clau)
}

#' @export
tallers.enunciat = function(num_pregunta, versio=NULL) {
  lib.uib20100.enunciat(num_pregunta=num_pregunta, versio=versio)
}

#' @export
tallers.comprova = function(num_pregunta, versio=NULL, ...) {
  lib.uib20100.comprova(num_pregunta=num_pregunta, versio=versio, ...)
}

#' @export
tallers.finalitza = function() {
  lib.uib20100.mostra_resum()
}


###
# DIAGONALITZACIÓ
###

#' @export
diagonalitza = function(matriu, veps_unitaris=FALSE) {
  if(is.null(dim(matriu))) {stop("Has proporcionat una matriu!")}
  if(dim(matriu)[1] != dim(matriu)[2]) {stop("La matriu ha de ser quadrada!")}

  n = dim(matriu)[1]
  descomposicio = eigen(matriu)
  D = diag(descomposicio$values)
  D = round(D, digits=6)
  if(all(Im(D)==0)) {D = Re(D)}
  P = descomposicio$vectors
  P = round(P, digits=6)
  if(all(Im(P)==0)) {P = Re(P)}
  if(!veps_unitaris) { # Primera normalització
    for(i in seq(1, n)) {
      values = P[ , i]
      values = c(Re(values), Im(values))
      values = abs(values)
      values = values[values > 1e-5]
      P[ , i] = P[ , i] / min(values)
    }
  }

  # Comprova si és diagonalitzable, canviant P i D
  es_diagonalitzable = TRUE
  etiqueta_matriu_diagonal = "D = "
  for(i in seq(2, n)) {
    if(qr(P[, 1:i])$rank != i) {
      es_diagonalitzable = FALSE
      etiqueta_matriu_diagonal = "E = "
      D[i-1, i] = 1
      # Trobar vector v tal que (A - lambda*I)*v = v_anterior
      v = qr.coef(qr(matriu - D[i, i]*diag(n)), P[ , i-1])
      posicions_na = is.na(v)
      v[posicions_na] <- 0
      P[ , i] = v
      num_iteracio = 0
      while(qr(P[, 1:i])$rank != i) {
        P[posicions_na, i] <- sample(1:num_iteracio, sum(posicions_na))
        if(num_iteracio > 100) {
          stop("No s'ha pogut calcular la forma normal d'aquesta matriu (no s'han trobat vectors suficients després de 100 iteracions)")
        }
      }
    }
  }
  if( class(try(solve(P),silent=T)) !="matrix" ) {
    stop("No s'ha pogut calcular la forma normal d'aquesta matriu (no s'han trobat vectors suficients: P no invertible)")
  }

  # Reordenam els VEPs/VAPs per a que els 1 surtin sota la diagonal:
  P = P[ , c(n:1), drop = FALSE]
  D = D[c(n:1), c(n:1), drop = FALSE]

  # Re-normalitza VEPs per (intentar) fer-los enters:
  if(!veps_unitaris) {
    cols_affected = vector("list", length=n)
    for(i in seq(1, n)) {
      if(isTRUE(D[i, i-1] == 1)) {
        cols_affected[[i]] = c(cols_affected[[i-1]], i)
      } else {
        cols_affected[[i]] = i
      }
    }
    cols_normalized = rep(FALSE, length=n)
    for(i in seq(n, 1, by=-1)) {
      if(!cols_normalized[i]) {
        cols = cols_affected[[i]]
        values = P[ , cols]
        values = c(Re(values), Im(values))
        values = abs(values)
        values = values[values > 1e-5]
        P[ , cols] = P[ , cols] / min(values)
        # Invert if starts with negative number
        idx_first_nonzero = which(Re(P[ , cols[1]]) != 0)[1]
        if(Re(P[idx_first_nonzero, cols[1]]) < 0) {
          P[ , cols] = -P[ , cols]
        }
        # Avoid decimals if possible
        max_factor = 16*9*25*7*11*13
        values = P[ , cols]
        values = c(Re(values), Im(values))
        values = abs(values)
        values = values[values > 1e-5]
        if(!all(values%%1 == 0) & all( (values*max_factor) %%1 == 0)) {
          gcd <- function(x,y) {
            r <- x%%y;
            return(ifelse(r, gcd(y, r), y))
          }
          gcd_multiple = function(v) {
            return(ifelse(
              length(v) == 2,
              gcd(v[1], v[2]),
              gcd(v[1], gcd_multiple(v[-1]))
            ))
          }
          factor = max_factor / gcd_multiple(values*max_factor)
          P[ , cols] = P[ , cols] * factor
        }

        # Mark all as normalized
        cols_normalized[cols] = TRUE
      }
    }
  }

  # Calcula P^{-1}
  Pinv = solve(P)

  # Comprova que abs(A - PDP^-1) = 0 (per el cas complexe)
  resultat_correcte = all(abs(matriu - P %*% D %*% Pinv) < 1e-4)
  if(!resultat_correcte) {
    stop("No s'ha pogut calcular la forma normal d'aquesta matriu (A != PDP^{-1})")
  }

  dades_out = list(
    "Matriu" = matriu,
    "Matriu D/E" = D,
    "P" = P
  )
  names(dades_out)[2] = if(es_diagonalitzable) "D" else "E"
  return(dades_out)
}

#' @export
mostra.diagonalitzacio = function(matriu_o_diagonalitzacio, decimals=2) {
  if(is.matrix(matriu_o_diagonalitzacio)) {
    dades = diagonalitza(matriu_o_diagonalitzacio)
  } else {
    dades = matriu_o_diagonalitzacio
  }
  if(!"E" %in% names(dades) & !"D" %in% names(dades)) stop("No hi ha matriu D/E.")
  if(!"P" %in% names(dades)) stop("No hi ha matriu P.")

  P = dades[["P"]]
  Pinv = solve(P)
  detP = prod(eigen(P)$values)
  dades_out = append(dades, list(
    "P^(-1)" = Pinv,
    "P^(-1) = 1/det(P) * P', on P'" = Pinv*detP,
    "det(P)" = detP
  ))
  names(dades_out) = paste(names(dades_out), " = ")
  for(n in names(dades_out)) {dades_out[[n]] = round(dades_out[[n]], digits=decimals)}
  return(lib.uib20100.utils.output(dades_out))
}
