


lib.uib20100.utils.is.number = function(...) {
  vars = list(...)
  stopifnot("Must call utils.is.number with only one variable."=length(var) == 1)
  if( length(names(vars)) == 1) {
    n = names(vars)[[1]]
  } else {
    call = grep(pattern="lib.uib20100.utils.is.number([^)]*)",
                x=.traceback(x = 1)[[2]],
                value=TRUE)
    n =  substr(call, 30, nchar(call)-1)
  }
  v = vars[[1]]
  error_str = sprintf("La variable `%s` hauria de ser un nombre.", n)
  if( is.null(v) ) {
    return(error_str)
  }
  if( length(v)!=1 ) {
    return(error_str)
  }
  if( !is.numeric(v) ) {
    return(error_str)
  }
}

lib.uib20100.utils.check.number = function(
  expected_value, given_value,
  max_relative_error=3e-2, max_absolute_error=0) {
  if(!is.null(lib.uib20100.utils.is.number(expected_value))) {
    return(list(
      "errlist" = list("El valor esperat hauria de ser numèric!"),
      "outlist" = list(),
      "punts" = NA
    ))
  }
  if(!is.null(lib.uib20100.utils.is.number(given_value))) {
    return(list(
      "errlist" = list("El valor proporcionat hauria de ser numèric!"),
      "outlist" = list(),
      "punts" = NA
    ))
  }
  dif = abs(expected_value - given_value)
  correct = (dif <= abs(max_relative_error*expected_value)) | (dif <= max_absolute_error)
  return(list(
    "errlist" = list(),
    "outlist" = list("Resposta correcta" = expected_value),
    "punts" = as.numeric(correct)
  ))
}



lib.uib20100.utils.is.matrix = function(...)  {
  vars = list(...)
  stopifnot("Must call utils.is.matrix with only one variable."=length(var) == 1)
  if( length(names(vars)) == 1) {
    n = names(vars)[[1]]
  } else {
    call = grep(pattern="lib.uib20100.utils.is.number([^)]*)",
                x=.traceback(x = 1)[[2]],
                value=TRUE)
    n =  substr(call, 30, nchar(call)-1)
  }
  v = vars[[1]]
  error_str = sprintf("La variable `%s` hauria de ser una matriu.", n)
  if( is.null(v) ) {
    return(error_str)
  }
  if( !is.matrix(v) ) {
    return(error_str)
  }
}

lib.uib20100.utils.check.matrix = function(
  expected_value, given_value, max_relative_error=3e-2) {
  # Returns list of $error, $punts
  if(!is.null(lib.uib20100.utils.is.matrix(expected_value))) {
    return(list(
      "errlist" = list("El valor esperat hauria de ser una matriu!"),
      "outlist" = list(),
      "punts" = NA
    ))
  }
  if(!is.null(lib.uib20100.utils.is.matrix(given_value))) {
    return(list(
      "errlist" = list("El valor proporcionat hauria de ser una matriu (`help(matrix)`)"),
      "outlist" = list(),
      "punts" = NA
    ))
  }
  if(!all(dim(expected_value) == dim(given_value))) {
    return(list(
      "errlist" = list("La matriu no té les dimensions correctes."),
      "outlist" = list(),
      "punts" = NA
    ))
  }
  valors_correctes = abs(expected_value - given_value) <= abs(max_relative_error*expected_value)
  correccio = given_value
  correccio[!valors_correctes] = NA
  return(list(
    "errlist" = list(),
    "outlist" = list("Resposta correcta" = lib.uib20100.utils.matrix2pandoc(correccio)),
    "punts" = sum(valors_correctes)/length(valors_correctes)
  ))
}


lib.uib20100.utils.check.combine = function(ponderacio=NULL, ...) {
  namedchecks = list(...)
  if(is.null(ponderacio)) {
    ponderacio = rep(1, times=length(namedchecks))
  }
  if(length(ponderacio) != length(namedchecks)) {stop("ERROR D'ENUNCIAT: Ponderació incorrecta")}
  llista_punts = rep(NA, times=length(namedchecks))
  outlist = list()
  errlist = list()
  for(idx in seq_along(namedchecks)) {
    n = names(namedchecks)[[idx]]
    v = namedchecks[[idx]]
    if("outlist" %in% names(v)) {
      vout = v[["outlist"]]
      for(nout in names(v[["outlist"]])) {
        outlist[sprintf("%s %s", nout, n)] = vout[[nout]]
      }
    }
    if("punts" %in% names(v)) {
      llista_punts[idx] = v[["punts"]]
    }
    if("errlist" %in% names(v)) {
      errlist = append(errlist, v[["errlist"]])
    }
  }
  return(list(
    "errlist" = errlist,
    "outlist" = outlist,
    "punts" = sum(ponderacio * llista_punts)/sum(ponderacio)
  ))
}
