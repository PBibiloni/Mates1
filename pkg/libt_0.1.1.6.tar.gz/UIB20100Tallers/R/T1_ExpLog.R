
t1 = function() {
  lib.uib20100.configura_info(
    num_taller=1,
    rubrica="Entrega el fitxer .Rmd i l'informe .html generat. A l'informe, explica
           el codi que utilitzis i el resultat que has obtingut.",
    rubrica_extra_punts=2,
    clau=21431
  )

  lib.uib20100.afegeixpregunta(
    num_taller=1,
    num_pregunta=1,
    punts=2,
    fun_inicialitzacio_aleatoria = function() {
      dades = data.frame(
        n = sample(seq(20, 90, by=10), 1)
      )
      return(dades)
    },
    fun_pregunta_com_str = function(dades) {
      return(sprintf("Calcula el logaritme de n=%d en base b=10", dades$n))
    },
    fun_comprova = function(dades, resposta) {
      errlst = append(list(), lib.uib20100.utils.is.number(resposta))
      if( length(errlst) != 0 ) {
        return(errlst)
      }
      return(lib.uib20100.utils.check.number(resposta, log(dades$n, base=10)))
    }
  )


  lib.uib20100.afegeixpregunta(
    num_taller=1,
    num_pregunta=2,
    punts=2,
    fun_inicialitzacio_aleatoria = function() {
      nums = sample(3:8, 3)
      dades = data.frame(
        a = nums[1],
        b = nums[2],
        c = nums[3]
      )
      return(dades)
    },
    fun_pregunta_com_str = function(dades) {
      return(sprintf("Resol a mà les següents equacions, i reflecteix al document
                     la resolució i el resultat final:
                    $%d = %d \\cdot x^{%d}$,
                    $%d = %d \\cdot {%d}^{y}$",
                     dades$a, dades$b, dades$c,
                     dades$a, dades$b, dades$c))
    },
    fun_comprova = function(dades, x, y) {
      errlst = append(list(), lib.uib20100.utils.is.number(x))
      errlst = append(errlst, lib.uib20100.utils.is.number(y))
      if( length(errlst) != 0 ) {
        return(errlst)
      }
      return(
        lib.uib20100.utils.check.number(dades$a, dades$b * x**(dades$c)) &
        lib.uib20100.utils.check.number(dades$a, dades$b * (dades$c)**y)
      )
    }
  )


  lib.uib20100.afegeixpregunta(
    num_taller=1,
    num_pregunta=3,
    punts=2,
    fun_inicialitzacio_aleatoria = function() {
      dades = data.frame(
        temps = 1:10,
        temperatura = 50 + sample(3:7, 1)*(1:10) + sample(3:7, 1)*runif(10)
      )
      return(dades)
    },
    fun_pregunta_com_str = function(dades) {
      return("En un experiment hem mesurat la temperatura [ºC] d'un sòlid en
           diferents instants de temps [s]. Hem guardat les dades a la variable
           `dades_experimentals`. Representa amb un gràfic lineal la temperatura
           en funció del temps, i dibuixa la recta de regressió lineal.")
    },
    fun_variables_per_alumne = function(dades) {
      vars = list(dades_experimentals=dades)
      return(vars)
    },
    str_codi_per_alumne = "
      # Les dades, guardades en una taula de dades o `dataframe`, les pots inspeccionar així:
      summary(dades_experimentals)
      # Pots seleccionar les columnes com:
      nova_variable = summary$temps
      # Per representar gràfiques adapta l'instrucció:
      plot(x = ..., y = ..., xlab = \"Etiqueta eix X\", ylab = \"Etiqueta eix Y\")
      # I per calcular/mostrar el model lineal:
      model = lm(VariableDepenent ~ VariableIndependent, data = dades_experimentals)
      abline(model)
    "
  )


  lib.uib20100.afegeixpregunta(
    num_taller=1,
    num_pregunta=4,
    punts=2,
    fun_inicialitzacio_aleatoria = function() {
      dades = data.frame(
        temps = 1:10,
        temperatura = 50 + sample(3:7, 1)*(1:10) + sample(3:7, 1)*runif(10)
      )
      return(dades)
    },
    fun_pregunta_com_str = function(dades) {
      return("Amb les dades de l'experiment de la pregunta anterior, no sabem si un
           ajust lineal és millor o pitjor que un ajust exponencial. Troba els
           paràmetres $a, b$ del millor ajust exponencial, que serà de la forma
           $y(x) = a \\cdot 10^{b \\cdot x}$.")
    },
    fun_variables_per_alumne = function(dades) {
      vars = list(dades_experimentals=dades)
      return(vars)
    },
    str_codi_per_alumne = "
      # Pots inspeccionar les dades:
      summary(dades_experimentals)
      # Per representar gràfiques adapta l'instrucció:
      plot(x = ..., y = ..., xlab = \"Etiqueta eix X\", ylab = \"Etiqueta eix Y\")
      # I per calcular/mostrar el model lineal:
      model = lm(VariableDepenent ~ VariableIndependent, data = dades_experimentals)
      abline(model)
    ",
    fun_comprova = function(dades, a, b) {
      errlst = append(list(), lib.uib20100.utils.is.number(a))
      errlst = append(errlst, lib.uib20100.utils.is.number(b))
      if( length(errlst) != 0 ) {
        return(errlst)
      }
      model = lm(log10(temperatura)~temps, data=dades)
      return(
        lib.uib20100.utils.check.number(a, 10^(model$coefficients[[1]])) &
        lib.uib20100.utils.check.number(b, model$coefficients[[2]])
      )
    }
  )
}
