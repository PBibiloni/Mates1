
#' @export
tallers.configura = function(taller=NULL, alumne=NULL, clau=NULL) {
  lib.uib20100.configura(taller=taller, alumne=alumne, clau=clau)
}

#' @export
tallers.enunciat = function(num_pregunta) {
  lib.uib20100.enunciat(num_pregunta=num_pregunta)
}

#' @export
tallers.comprova = function(num_pregunta, ...) {
  lib.uib20100.comprova(num_pregunta, ...)
}
