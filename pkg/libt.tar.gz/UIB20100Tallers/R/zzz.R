
.onLoad <- function(libname, pkgname) {
  t1()
}
