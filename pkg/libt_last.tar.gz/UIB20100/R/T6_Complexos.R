
t6 = function() {
  lib.uib20100.configura_info(
    num_taller=6,
    rubrica="Entrega el fitxer .Rmd i l'informe .html generat. A l'informe, explica
           el codi que utilitzis i el resultat que has obtingut.",
    clau=61833
  )

  lib.uib20100.afegeixpregunta(
    num_taller=6,
    num_pregunta=1,
    punts=2,
    fun_inicialitzacio_aleatoria = function() {
      M = sample(list(
        matrix(c(0, 1, -1, 0), nrow=2),
        matrix(c(1, 2, -1, -1), nrow=2),
        matrix(c(2, 5, -1, -2), nrow=2),
        matrix(c(3, 10, -1, -3), nrow=2),
        matrix(c(-1, 2, -1, 2), nrow=2),
        matrix(c(-2, 5, -1, 2), nrow=2)
      ), size=1)[[1]]
      return(list("M"=M))
    },
    fun_variables_per_alumne = function(dades) {
      vars = list(M=dades$M)
      return(vars)
    },
    fun_pregunta_com_str = function(dades) {
      return("Troba, a mà o amb R, un vector propi de la matriu $M$.
             Comprova que $M \\cdot v = \\lambda \\cdot v$.")
    }
  )

  lib.uib20100.afegeixpregunta(
    num_taller=6,
    num_pregunta=2,
    punts=2,
    fun_contexte_com_str = function(dades) {
      return("D'una matriu $A$, sabem que és quadrada i de mida $2 \\times 2$.
             També sabem que $(1, 2)^t$ és vector propi de valor propi 2,
             i que $(1, 3)^t$ és vector propi de valor propi 3.")
    },
    fun_pregunta_com_str = function(dades) {
      return("
        Si és possible, troba a mà o amb R la matriu $A$. Si no és possible, explica per què no.")
    }
  )

  lib.uib20100.afegeixpregunta(
    num_taller=6,
    num_pregunta=3,
    punts=2,
    fun_contexte_com_str = function(dades) {
      return("Hem trobat la successió $x_n=2i(\\sqrt{3}+i)^n-2i(\\sqrt{3}-i)^n$.
             Curiosament, tots els valors són reals: $x_0 = 0$, $x_1 = -4$, $x_2 = -13.86$...")
    },
    fun_pregunta_com_str = function(dades) {
      return("Troba, amb la fórmula de de Moivre, una expressió de $x_n$ sense nombres complexos.
             És a dir, expressa la successió com $x_n = a^n \\cdot \\cos(xn) + b^n \\cdot \\sin(yn)$.")
    }
  )


  contexte.bacteries = function(dades) {
    return("Estudiant dues poblacions de llevats, que anomenarem $A$ i $B$,
           hem comprovat que: si disposem 1 gram d'$A$ i 3 grams de $B$, passats una hora
           trobarem 1.1 grams d'$A$ i 3.3 grams de $B$.
           Per altra part, si només posam 1 gram de $B$, passada una hora ens trobam,
           de mitjana, amb 1.4 grams de $B$.")
  }
  lib.uib20100.afegeixpregunta(
    num_taller=6,
    num_pregunta=4,
    punts=2,
    fun_contexte_com_str = contexte.bacteries,
    fun_pregunta_com_str = function(dades) {
      return("Assumint que la dependència entre les poblacions la podem expressar
             mitjançant un model malthusià matricial, troba aquest model.")
    }
  )

  lib.uib20100.afegeixpregunta(
    num_taller=6,
    num_pregunta=5,
    punts=2,
    fun_contexte_com_str = contexte.bacteries,
    fun_pregunta_com_str = function(dades) {
      return("Digues quina serà la població 20 hores després d'haver dipositat
             1 gram d'$A$ i 3 grams de $B$.")
    }
  )

}
