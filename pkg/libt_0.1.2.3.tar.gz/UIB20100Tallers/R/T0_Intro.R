
t0 = function() {
  lib.uib20100.configura_info(
    num_taller=0,
    clau=93481
  )

  lib.uib20100.afegeixpregunta(
    num_taller=0,
    num_pregunta=1,
    punts=10,
    fun_pregunta_com_str = function(dades) {
      return("Suma 2 + 2")
    },
    fun_comprova = function(dades, resposta) {
      return(lib.uib20100.utils.check.number(resposta, 4))
    }
  )
}
