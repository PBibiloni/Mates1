
.onLoad <- function(libname, pkgname) {
  t0()
  t1()
  t4()
  t6()
}
