
t7 = function() {
  lib.uib20100.configura_info(
    num_taller=7,
    rubrica="Entrega el fitxer .Rmd i l'informe .html generat. A l'informe, explica
           el codi que utilitzis i el resultat que has obtingut.",
    clau=98767
  )

  lib.uib20100.afegeixpregunta(
    num_taller=7,
    num_pregunta=1,
    punts=2.5,
    fun_inicialitzacio_aleatoria = function() {
      return(list(
        "a"=sample(c(2,3,4,5,6), size=1)
      ))
    },
    fun_contexte_com_str = function(dades) {
      return(sprintf(
        "Sabem que la sucessió $(x_n)_n$ satistfà l'equació en diferències
        $x_{n+2} = x_{n+1} + %d \\cdot x_{n}$.
        També sabem que $x_0 = 0$, i que $x_2 = 2$.", dades$a))
    },
    fun_pregunta_com_str = function(dades) {
      return("Què val $x_{3}$?")
    }
  )

  fun_contexte_gamers = function(dades) {
    return(
      "Els jocs online `Among us` i `Fall Dudes` han tingut un gran creixement
      recentment, i ens han encarregat realitzar un estudi de com evolucionen
      les seves poblacions al llarg de les setmanes.
      Per una part, s'ha observat que Among Us manté els jugadors de la setmana anterior,
      i a més guanya 2 jugadors per cada jugador de Fall Dudes de la setmana anterior.
      Per altra part, Fall Dudes manté els jugadors que tenia la setmana anterior,
      però perd 2 jugadors per cada jugador que Among Us tenia la setmana anterior.")
  }

  lib.uib20100.afegeixpregunta(
    num_taller=7,
    num_pregunta=2,
    punts=2.5,
    fun_inicialitzacio_aleatoria = function() {
      return(list(
        "a"=sample(c(2,3,4,5,6), size=1)
      ))
    },
    fun_contexte_com_str = fun_contexte_gamers,
    fun_pregunta_com_str = function(dades) {
      return(
        "Determina les relacions que modelen les poblacions de jugadors d'Among Us
        i de jugadors de Fall Dudes.
        Escriu-les en forma d'equacions i en forma matricial.")
    }
  )

  lib.uib20100.afegeixpregunta(
    num_taller=7,
    num_pregunta=3,
    punts=1.5,
    fun_inicialitzacio_aleatoria = function() {
      return(list(
        "a"=sample(c(2,3,4,5,6), size=1)
      ))
    },
    fun_contexte_com_str = fun_contexte_gamers,
    fun_pregunta_com_str = function(dades) {
      return(
        "Determina a mà els valors propis de la matriu que has obtingut.")
    }
  )

  lib.uib20100.afegeixpregunta(
    num_taller=7,
    num_pregunta=4,
    punts=1.5,
    fun_inicialitzacio_aleatoria = function() {
      return(list(
        "a"=sample(c(2,3,4,5,6), size=1)
      ))
    },
    fun_contexte_com_str = fun_contexte_gamers,
    fun_pregunta_com_str = function(dades) {
      return(
        "Determina, a mà amb R, la descomposició diagonal de la matriu que has obtingut.
        Comprova, a mà amb R, que la descomposició diagonal és correcta (és a dir, que
        $M = P \\cdot D \\cdot P^{-1}$).")
    }
  )

  lib.uib20100.afegeixpregunta(
    num_taller=7,
    num_pregunta=5,
    punts=2,
    fun_inicialitzacio_aleatoria = function() {
      return(list(
        "a"=sample(c(2,3,4,5,6), size=1)
      ))
    },
    fun_contexte_com_str = fun_contexte_gamers,
    fun_pregunta_com_str = function(dades) {
      return(
        "L'estudi va començar durant el llençament d'Among Us, on suposarem que
        no tenia cap jugador, moment en el que Fall Dudes ja tenia una base
        establerta de 2000 jugadors.
        Amb aquestes dades, proporciona una expressió per al nombre de jugadors d'Among Us
        que només depengui del nombre de setmanes que han passat des de que va començar l'estudi.")
    }
  )

}
