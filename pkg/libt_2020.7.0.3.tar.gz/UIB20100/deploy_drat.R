# Configure build files
setwd("~/RStudio Projects/UIB20100Tallers")
devtools::document()
version = devtools::as.package(".")$version
# Commit and push
system("git pull", wait=FALSE)
system(sprintf("git commit -m \"Deploy %s\"", version))
system("git push", wait=FALSE)
# Build
setwd("~/RStudio Projects")
if(.Platform$OS.type == "unix") {Rcmd = "Rcmd"} else {Rcmd = "R CMD"}
system(sprintf("%s build --md5 UIB20100Tallers", Rcmd))
# Deploy with drat
drat::insertPackage(sprintf("UIB20100Tallers_%s.tar.gz", version),
                    repodir="~/RStudio Projects/drat", commit=TRUE)
setwd("~/RStudio Projects/drat")
system("git push", wait=FALSE)
# Get back to this project
setwd("~/RStudio Projects/UIB20100Tallers")
# Output
writeLines(sprintf("NEW VERSION:  %s", version, version))
