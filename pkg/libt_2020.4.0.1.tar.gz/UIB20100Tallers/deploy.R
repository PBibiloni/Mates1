# Configure build files
setwd("~/RStudio Projects/UIB20100Tallers")
devtools::document()
version = devtools::as.package(".")$version
# Commit and push
system("git pull", wait=FALSE)
system(sprintf("git commit -m \"Deploy %s\"", version))
system("git push", wait=FALSE)
# Build`
setwd("~/RStudio Projects")
if(.Platform$OS.type == "unix") {Rcmd = "Rcmd"} else {Rcmd = "R CMD"}
system(sprintf("%s build --md5 UIB20100Tallers", Rcmd))
# Move into Mates1 repo
system(sprintf("cp UIB20100Tallers_%s.tar.gz Mates1/pkg/libt_%s.tar.gz", version, version))
system(sprintf("mv UIB20100Tallers_%s.tar.gz Mates1/pkg/libt_last.tar.gz", version))
# Push build into Mates1 source
setwd("~/RStudio Projects/Mates1")
system(sprintf("git add pkg/libt_last.tar.gz", version))
system(sprintf("git add pkg/libt_%s.tar.gz", version))
system(sprintf("git commit -m \"Deploy pkg_%s\" pkg/libt_%s.tar.gz pkg/libt_last.tar.gz", version, version))
system("git push", wait=FALSE)
# Get back to this project
setwd("~/RStudio Projects/UIB20100Tallers")
# Output new url
writeLines(sprintf("
  NEW URL:      https://github.com/PBibiloni/Mates1/raw/master/pkg/libt_%s.tar.gz
  NEW VERSION:  %s", version, version))
