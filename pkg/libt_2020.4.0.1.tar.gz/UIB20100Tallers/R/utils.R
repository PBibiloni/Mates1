

lib.uib20100.utils.output = function(list_outputs, header=" ") {
  list_outputs = Filter(Negate(is.null), list_outputs)
  list_outputs = lapply(list_outputs, lib.uib20100.utils.encodehtml)
  df = data.frame(v=matrix(unlist(list_outputs), nrow=length(list_outputs), byrow=T),
                  stringsAsFactors = FALSE)
  if(is.null(names(list_outputs))) {
    rownames(df) = lapply(seq_along(list_outputs), function(i) {paste(rep(' ', i),collapse=" ")})
  } else {
    rownames(df) = lapply(names(list_outputs), lib.uib20100.utils.encodehtml)
  }
  return(knitr::kable(df, col.names = c(header)))
}

lib.uib20100.utils.outputcodi = function(multiline_string, header="Codi") {
  list_lines = strsplit(multiline_string, "\n")[[1]]
  list_lines = lapply(list_lines, function(l) {
    trimws(l, which = c("both", "left", "right"))})
  list_lines = Filter(function(l) {nchar(l) > 0}, list_lines)
  # list_lines = lapply(list_lines, lib.uib20100.utils.encodehtml)
  df = data.frame(Codi=paste("`", unlist(list_lines, use.names=FALSE), "`", sep=""),
                  stringsAsFactors = FALSE)
  return(knitr::kable(df, col.names = c(header)))
}

lib.uib20100.utils.outputerror = function(error_str) {
  return(lib.uib20100.utils.output(
    list(" " = error_str),
    header="ERROR"))
}

lib.uib20100.utils.outputerror.noconfig = function() {
  return(lib.uib20100.utils.outputerror(
      "Encara no has configurat el taller. Executa el chunk que
      conté la instrucció `configura.taller( ... )` i comprova que no dona cap error."
  ))
}



lib.uib20100.utils.encodehtml = function(string) {
  specialchars = list(
    "á"="&aacute;", "à"="&agrave;", "Á"="&Aacute;", "À"="&Agrave;", "ä"="&auml;", "Ä"="&Auml;",
    "é"="&eacute;", "è"="&egrave;", "É"="&Eacute;", "È"="&Egrave;", "ë"="&euml;", "Ë"="&Euml;",
    "í"="&iacute;", "ì"="&igrave;", "Í"="&Iacute;", "Ì"="&Igrave;", "ï"="&iuml;", "Ï"="&Iuml;",
    "ó"="&oacute;", "ò"="&ograve;", "Ó"="&Oacute;", "Ò"="&Ograve;", "ö"="&ouml;", "Ö"="&Ouml;",
    "ú"="&uacute;", "ù"="&ugrave;", "Ú"="&Uacute;", "Ù"="&Ugrave;", "ü"="&uuml;", "Ü"="&Uuml;",
    "ç"="&ccedil;", "Ç"="&ccedil;",
    "ñ"="&ntilde;", "Ñ"="&Ntilde;",
    "º"="&deg;",
    "\n"="" # Also, avoid line breaks within a string
  )
  result <- string
  for (pattern in names(specialchars)) {
    result <- gsub(pattern, specialchars[[pattern]], result)
  }
  return(result)
}



lib.uib20100.utils.is.number = function(...) {
  vars = list(...)
  stopifnot("Must call utils.is.number with only one variable."=length(var) == 1)
  if( length(names(vars)) == 1) {
    n = names(vars)[[1]]
  } else {
    call = grep(pattern="lib.uib20100.utils.is.number([^)]*)",
                x=.traceback(x = 1)[[2]],
                value=TRUE)
    n =  substr(call, 30, nchar(call)-1)
  }
  v = vars[[1]]
  error_str = sprintf("La variable `%s` hauria de ser un nombre.", n)
  if( is.null(v) ) {
    return(error_str)
  }
  if( length(v)!=1 ) {
    return(error_str)
  }
  if( !is.numeric(v) ) {
    return(error_str)
  }
}

lib.uib20100.utils.check.number = function(
  expected_value, given_value, max_relative_error=3e-2) {
  if(!is.null(lib.uib20100.utils.is.number(expected_value))) {
    return(list("error" = "ERROR A L'ENUNCIAT! El valor esperat hauria de ser numèric!"))
  }
  if(!is.null(lib.uib20100.utils.is.number(given_value))) {
    return(list("error" = "El valor proporcionat hauria de ser numèric"))
  }
  return(list("punts" = abs(expected_value - given_value) <= abs(max_relative_error*expected_value)))
}



lib.uib20100.utils.is.matrix = function(...)  {
  vars = list(...)
  stopifnot("Must call utils.is.matrix with only one variable."=length(var) == 1)
  if( length(names(vars)) == 1) {
    n = names(vars)[[1]]
  } else {
    call = grep(pattern="lib.uib20100.utils.is.number([^)]*)",
                x=.traceback(x = 1)[[2]],
                value=TRUE)
    n =  substr(call, 30, nchar(call)-1)
  }
  v = vars[[1]]
  error_str = sprintf("La variable `%s` hauria de ser una matriu.", n)
  if( is.null(v) ) {
    return(error_str)
  }
  if( !is.matrix(v) ) {
    return(error_str)
  }
}

lib.uib20100.utils.check.matrix = function(
  expected_value, given_value, max_relative_error=3e-2) {
  # Returns list of $error, $punts
  if(!is.null(lib.uib20100.utils.is.matrix(expected_value))) {
    return(list("error" = "ERROR A L'ENUNCIAT! El valor esperat hauria de ser una matriu!"))
  }
  if(!is.null(lib.uib20100.utils.is.matrix(given_value))) {
    return(list("error" = "El valor proporcionat hauria de ser una matriu (`help(matrix)`)"))
  }
  if(!all(dim(expected_value) == dim(given_value))) {
    return(list("error" = "La matriu no té les dimensions correctes."))
  }
  valors_correctes = abs(expected_value - given_value) <= abs(max_relative_error*expected_value)
  return(list("punts" = sum(valors_correctes)/length(valors_correctes)))
}

lib.uib20100.utils.number2str <- function(x, max_decimals=2) {
  x = round(x, digits=max_decimals)
  return(paste(x))
}

lib.uib20100.utils.matrix2latex <- function(A, name="", decimals=2, environment="pmatrix") {
  if(is.null(dim(A))) {   # Un escalar
    return(paste(
      name,
      lib.uib20100.utils.number2str(A, max_decimals=decimals)
    ))
  }
  A = t(A)
  A = apply(A, 1, lib.uib20100.utils.number2str, max_decimals=decimals)
  paste(
    name,
    "\\begin{", environment, "}\n \t",
    paste(apply(A, 1, function(x) {paste(x , collapse=" & ")}), collapse=" \\\\ \n \t"),
    "\n\\end{", environment, "}",
    sep = "")
}

lib.uib20100.utils.matrix2pandoc = function(A, name="", decimals=2) {
  if(is.null(dim(A))) {
    # Escalar
    return(knitr::kable(
      paste(name, lib.uib20100.utils.number2str(A, max_decimals=decimals)),
      col.names=c(" "),
      format = 'pipe'
    ))
  }
  A = t(A)
  A = apply(A, 1, lib.uib20100.utils.number2str, max_decimals=decimals)
  etiqueta = matrix(rep("", times=dim(A)[[1]]), ncol=1)
  etiqueta[round(dim(A)[[1]]/2), 1] = name
  if(dim(A)[[1]] == 1 & dim(A)[[2]] == 1) {
    padding_left = matrix(" ", ncol=1)
    padding_right = matrix(" ", ncol=1)
  } else if(dim(A)[[1]] == 1) {
    padding_left = matrix("(", ncol=1)
    padding_right = matrix(")", ncol=1)
  } else {
    padding_left = matrix(c('/', rep("|", times=dim(A)[[1]]-2), '\\\\'), ncol=1)
    padding_right = matrix(c('\\\\', rep("|", times=dim(A)[[1]]-2), '/'), ncol=1)
  }
  A_str = cbind(etiqueta, padding_left, A, padding_right)

  return(knitr::kable(
    A_str,
    col.names=rep(" ", times=dim(A_str)[[2]]),
    align = paste(c('c', rep('r', dim(A)[[1]]), 'c'), sep=""),
    format = 'pipe'
  ))
}
