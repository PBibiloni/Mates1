
###
# TALLERS
###


#' @export
tallers.configura = function(taller=NULL, alumne=NULL, clau=NULL) {
  lib.uib20100.configura(taller=taller, alumne=alumne, clau=clau)
}

#' @export
tallers.enunciat = function(num_pregunta) {
  lib.uib20100.enunciat(num_pregunta=num_pregunta)
}

#' @export
tallers.comprova = function(num_pregunta, ...) {
  lib.uib20100.comprova(num_pregunta, ...)
}

#' @export
tallers.finalitza = function() {
  lib.uib20100.mostra_resum()
}


###
# DIAGONALITZACIÓ
###

#' @export
diagonalitza = function(A) {
  descomposicio = eigen(A)
  D = diag(descomposicio$values)
  P = descomposicio$vectors
  P = P / min(P)
  Pinv = solve(P)
  detP = det(P)

  mostra_matriu <- function(M, nom="Matriu") {
    out <- capture.output(M)
    cat(paste(c(nom, out, '\n'), collapse="\n"))
  }

  mostra_valor <- function(v, nom="Valor") {
    cat(sprintf("%s: %f\n\n", nom, v))
  }

  k1 = lib.uib20100.utils.output(list(
    "Matriu original:" = sprintf("A = %s", lib.uib20100.utils.matrix2latex(A)),
    "Descomposició:" = sprintf("P \\cdot D \\cdot P^{-1} = \\frac{1}{%f} %s %s %s",
                               detP,
                               lib.uib20100.utils.matrix2latex(P),
                               lib.uib20100.utils.matrix2latex(D),
                               lib.uib20100.utils.matrix2latex(Pinv*detP))
  ), header="Descomposició diagonal")
}
